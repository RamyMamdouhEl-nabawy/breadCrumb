import React, { Component } from "react";
// import logo from "./logo.svg";
import BreadCrumb, { alignment } from "./components/breadCrumbs";
import { Route, Switch, Redirect } from "react-router-dom";
import "./App.css";
import Home from "./components/home";
import About from "./components/About";

let d = [
  { text: "Google", link: "http://www.google.com" },
  { text: "ITWorx", link: "https://www.itworx-hub.com/" },
  { text: "Home", link: "/Home" },
  { text: "About", link: "/About" }
];

class App extends Component {
  render() {
    return (
      <div className="App">
        <BreadCrumb data={d} alignment={alignment.ltr} />
        <Switch>
          <Route path="/http://www.google.com" exact component={Home} />
          <Route path="/https://www.itworx-hub.com/" exact component={Home} />
          <Route path="/Home" exact component={Home} />
          <Route path="/About" exact component={About} />
          <Redirect to="/About" />
        </Switch>
      </div>
    );
  }
}

export default App;
