import React from "react";

const About = () => {
  return <h2>About</h2>;
};

export default About;
