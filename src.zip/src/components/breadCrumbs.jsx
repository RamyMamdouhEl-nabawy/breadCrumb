import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import "./styles.scss";

const propTypes = {
  data: PropTypes.array.isRequired,
  alignment: PropTypes.string
};

const defaultProps = {
  alignment: "ltr"
};

// breadCrumbs component.
class BreadCrumbs extends React.Component {
  state = {
    data: [...this.props.data]
    // disabled: false
  };

  // constructor for binding events.
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
    this.handleDisable = this.handleDisable.bind(this);
  }

  // Handler for making last link in array disabled from click.
  handleDisable = event => {
    event.preventDefault();
  };

  // Handler for removing elements after clicked one from array.
  handleClick = index => {
    const data = [...this.state.data];
    const ind = index + 1;
    const len = this.state.data.length - ind;
    data.splice(ind, len);
    this.setState({ data });
  };

  // making a condition that check the position of entity.
  shape =
    this.props.alignment.toLowerCase() === "ltr" ? (
      <span className="ltr shape"> / </span>
    ) : (
      <span className="rtl shape"> \ </span>
    );
  // &gt;
  // &lt;
  render() {
    const { alignment } = this.props;
    const { data } = this.state;

    return data.map((r, index) => {
      if (index === data.length - 1)
        return (
          <span key={r.text}>
            <Link
              to={r.link}
              className={`txt ${alignment.toLowerCase()} `}
              onClick={this.handleDisable}
            >
              {r.text}
            </Link>
          </span>
        );
      return (
        <div key={r.text}>
          <Link
            className={`lin ${alignment.toLowerCase()} `}
            to={r.link}
            onClick={() => this.handleClick(index)}
          >
            {r.text}
          </Link>
          {this.shape}
        </div>
      );
    });
  }
}
// validation of passed props.
BreadCrumbs.propTypes = propTypes;

// dafault values of passed props.
BreadCrumbs.defaultProps = defaultProps;
export default BreadCrumbs;
// export choices for alignemnt.
export const alignment = {
  ltr: "ltr",
  rtl: "rtl"
};
